# Install: python -m pip install pandas numpy scikit-learn
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer

from pathlib import Path

csv_path = Path("netflix_titles.csv")
if csv_path.exists():
    df = pd.read_csv(csv_path)
    print("Loaded dataset: netflix_titles.csv (as in the practical PDF)")
else:
    print("WARNING: netflix_titles.csv not found. Using a small fallback sample; output will differ from the PDF dataset.")
    df = pd.DataFrame({
        "Age": [22, 25, np.nan, 120, 29, 31],
        "Salary": [25000, 32000, 28000, 50000, np.nan, 42000],
        "City": ["mumbai", "PUNE", "Mumbai ", "Navi Mumbai", None, "pune"]
    })
print("\nOriginal data (first 10 rows):\n", df.head(10))

# Standardize inconsistent text formatting for all text columns.
for col in df.select_dtypes(include="object").columns:
    df[col] = df[col].astype("string").str.strip()

# Impute missing values: median for numeric, most frequent for categorical.
num_cols = df.select_dtypes(include=np.number).columns.tolist()
cat_cols = df.select_dtypes(include=["object", "string", "category"]).columns.tolist()
if num_cols:
    df[num_cols] = SimpleImputer(strategy="median").fit_transform(df[num_cols])
if cat_cols:
    for col in cat_cols:
        df[col] = df[col].fillna("Unknown")

# Cap numeric outliers using the IQR rule.
for col in num_cols:
    q1, q3 = df[col].quantile([0.25, 0.75])
    iqr = q3 - q1
    if iqr > 0:
        df[col] = df[col].clip(q1 - 1.5 * iqr, q3 + 1.5 * iqr)

print("\nCleaned data (first 10 rows):\n", df.head(10))
print("\nMissing values after cleaning:\n", df.isnull().sum())
print("\nDataset shape:", df.shape)
