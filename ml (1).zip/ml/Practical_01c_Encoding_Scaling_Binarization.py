# Install: python -m pip install pandas scikit-learn
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler, Binarizer

df = pd.DataFrame({
    "City": ["Mumbai", "Pune", "Nashik", "Mumbai"],
    "Age": [21, 25, 30, 23],
    "Score": [45, 70, 85, 60]
})
print("Original:\n", df)
le = LabelEncoder()
df["City_Label"] = le.fit_transform(df["City"])
df["Age_Standardized"] = StandardScaler().fit_transform(df[["Age"]])
df["Score_MinMax"] = MinMaxScaler().fit_transform(df[["Score"]])
df["Score_Binary"] = Binarizer(threshold=60).fit_transform(df[["Score"]]).astype(int)
print("\nTransformed:\n", df)
print("\nCity label mapping:", dict(zip(le.classes_, le.transform(le.classes_))))
