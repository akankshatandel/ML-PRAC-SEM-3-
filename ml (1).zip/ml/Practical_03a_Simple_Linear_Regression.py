# Install: python -m pip install numpy matplotlib scikit-learn
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

X = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1)
y = np.array([15, 18, 21, 25, 28, 31, 35, 38, 41, 45])
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression().fit(X_train, y_train)
pred = model.predict(X_test)
print("Coefficient:", model.coef_[0])
print("Intercept:", model.intercept_)
print("Predictions:", pred)
print("MSE:", mean_squared_error(y_test, pred))
print("R-squared:", r2_score(y_test, pred))
plt.scatter(X, y, label="Data")
plt.plot(X, model.predict(X), label="Regression line")
plt.xlabel("Study hours"); plt.ylabel("Score"); plt.legend(); plt.show()
