# Install: python -m pip install pandas scikit-learn
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

path = Path("knn_data.csv")
if not path.exists():
    pd.DataFrame({
        "Height": [150, 155, 160, 162, 165, 170, 172, 175, 180, 185, 158, 178],
        "Weight": [48, 50, 52, 54, 57, 60, 62, 65, 72, 78, 51, 68],
        "Class": ["A", "A", "A", "A", "A", "B", "B", "B", "B", "B", "A", "B"]
    }).to_csv(path, index=False)
    print("Created sample CSV:", path.resolve())
df = pd.read_csv(path)
X, y = df.drop(columns="Class"), df["Class"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
model = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=3))
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("Accuracy:", round(accuracy_score(y_test, pred), 4))
print("\nCorrect predictions:")
for actual, guessed in zip(y_test.to_numpy(), pred):
    if actual == guessed: print(f"Actual={actual}, Predicted={guessed}")
print("\nIncorrect predictions:")
for actual, guessed in zip(y_test.to_numpy(), pred):
    if actual != guessed: print(f"Actual={actual}, Predicted={guessed}")
