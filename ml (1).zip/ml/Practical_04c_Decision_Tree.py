# Install: python -m pip install scikit-learn matplotlib
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score, classification_report

data = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42, stratify=data.target
)
model = DecisionTreeClassifier(max_depth=3, min_samples_leaf=2, random_state=42)
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("Accuracy:", round(accuracy_score(y_test, pred), 4))
print(classification_report(y_test, pred, target_names=data.target_names))
plt.figure(figsize=(14, 8))
plot_tree(model, feature_names=data.feature_names, class_names=data.target_names,
          filled=True, rounded=True)
plt.tight_layout(); plt.show()
