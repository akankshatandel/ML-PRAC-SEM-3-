# Install: python -m pip install scikit-learn
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

data = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42, stratify=data.target
)
model = GaussianNB()
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("Prior class probabilities:", model.class_prior_)
print("Accuracy:", round(accuracy_score(y_test, pred), 4))
print("Confusion matrix:\n", confusion_matrix(y_test, pred))
print(classification_report(y_test, pred, target_names=data.target_names))
sample = X_test[:1]
print("Sample features:", sample[0])
print("Posterior probabilities:", model.predict_proba(sample)[0])
print("Predicted class:", data.target_names[model.predict(sample)[0]])
